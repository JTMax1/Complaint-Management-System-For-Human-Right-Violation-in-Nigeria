const form = document.querySelector('form');

form.addEventListener('submit', (event) => {
  event.preventDefault();
  const typeOfViolation = document.getElementById('type-of-violation').value;
  const date = document.getElementById('date').value;
  const time = document.getElementById('time').value;
  const location = document.getElementById('location').value;
  const victimName = document.getElementById('victim-name').value;
  const victimAge = document.getElementById('victim-age').value;
  const victimGender = document.getElementById('victim-gender').value;
  const victimContact = document.getElementById('victim-contact').value;
  const perpetratorName = document.getElementById('perpetrator-name').value;
  const perpetratorPosition = document.getElementById('perpetrator-position').value;
  const evidenceDescription = document.getElementById('evidence-description').value;

  // Validation checks
  if (!typeOfViolation || !date || !time || !location || !victimName || !victimAge || !victimGender || !victimContact || !perpetratorName || !perpetratorPosition || !evidenceDescription) {
    alert('Please fill in all fields!');
    return false;
  }
  
  // Submit the form
  const report = {
    typeOfViolation: typeOfViolation,
    date: date,
    time: time,
    location: location,
    victim: {
      name: victimName,
      age: victimAge,
      gender: victimGender,
      contact: victimContact
    },
    perpetrator: {
      name: perpetratorName,
      position: perpetratorPosition
    },
    evidence: {
      description: evidenceDescription
    }
  };
  
  console.log('Report submitted:', report);
  alert('Your report has been submitted. Reference number: 1234');
  form.reset();
});
