var input = document.querySelectorAll("#phone");
window.intlTelInput(input, {
    separateDialCode: true,
    excludeCountries: ["in", "il"],
    preferredCountries: ["ru", "jp", "pk", "no"]
});

var input = document.querySelector("#phone");
window.intlTelInput(input, {
    separateDialCode: true,
    excludeCountries: ["in", "il"],
    preferredCountries: ["ru", "jp", "pk", "no"]
});

//var input = document.querySelector("#phone");
//window.intlTelInput(input, {
    // show dial codes too
   // separateDialCode: true,
    // If there are some countries you want to show on the top.
    // here we are promoting russia and singapore.
    //preferredCountries: ["ru", "sg"],
    //Default country
    //initialCountry:"sg",
    // show only these countres, remove all other
    //onlyCountries: ["ru", "cn","pk", "sg", "my", "bd"],
    // If there are some countries you want to execlde.
    // here we are exluding india and israel.
    //excludeCountries: ["in","il"]
//});
