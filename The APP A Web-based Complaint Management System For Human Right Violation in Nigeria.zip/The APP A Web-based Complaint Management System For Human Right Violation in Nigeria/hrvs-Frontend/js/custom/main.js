const deleteCommunity = (id) => {
    if (confirm('Are you sure you want to delete this community?')) {
        let formEl = `delete-community-${id}`;
        document.getElementById(formEl).submit();
    }
}

const deleteForm = (id) => {
    if (confirm('Are you sure you want to delete this Form?')) {
        let formEl = `delete-form-${id}`;
        document.getElementById(formEl).submit();
    }
}

const deleteItem = (id, name) => {
    if (confirm(`Are you sure you want to delete this ${name}?`)) {
        let itemEl = `delete-${id}`;
        document.getElementById(itemEl).submit();
    }
}

const getLGAsByStateId = (stateField, lgaField) => {
    let stateId = $(stateField).val();
    $(lgaField).empty().append('<option></option>');
    $.getJSON(`/api/v2/location/states/${stateId}/lgas`, {}, lgas => {
        lgas.forEach(lga => {
            $(lgaField).append(`<option value="${lga.id}" data-name="${lga.lga_name}">${lga.lga_name}</option>`);
        });
    });
}

const getLGAbyId = lgaElement => {
    let id = $(lgaElement).val();
    $(lgaElement).empty();
    $.getJSON(`/api/v2/location/lgas/${id}`, {}, data => {
        // $(lgaElement).append(`<option value="${lga.id}" selected>${lga.lga_name}</option>`);

        $(lgaElement).append(`<option value="${data.lga.id}" selected>${data.lga.lga_name}</option>`);

        data.otherLGAs.forEach(lga => {
            $(lgaElement).append(`<option value="${lga.id}">${lga.lga_name}</option>`);
        });

    });
}

const getCommunityByLGAId = (lgaField, communityField) => {
    let lgaId = $(lgaField).val();
    $(communityField).empty().append('<option></option>');;
    $.getJSON(`/api/v2/location/lgas/${lgaId}/communities`, {}, communities => {
        if (communities.length == 0) {
            $(communityField).append(`<option disabled>No community yet!</option>`);
            return;
        }
        communities.forEach(community => {
            $(communityField).append(`<option value="${community.id}">${community.name}</option>`);
        });
    });
}

const getCommunityById = communityElement => {
    let id = $(communityElement).val();
    $(communityElement).empty();
    $.getJSON(`/api/v2/location/communities/${id}`, {}, data => {
        $(communityElement).append(`<option value="${data.community.id}" selected>${data.community.name}</option>`);

        data.otherCommunities.forEach(community => {
            $(communityElement).append(`<option value="${community.id}">${community.name}</option>`);
        });
    });
}

const team = function () {
    $.getJSON(`/c/teams/all`, {}, team => {

        team.forEach(team => {
            $('input[name="team_id"]').append(`<option value="${team.id}">${team.name}</option>`);
        });
    });
};


const getTeamMembers = (memberField = '.teamMembersSelect', teamField = '.teamSelect') => {
    let teamId = $(teamField).val();
    $(memberField).empty().append('<option></option>');
    $.getJSON(`/c/team/${teamId}/members`, {}, members => {
        members.results.forEach(member => {
            $(memberField).append(`<option value="${member.id}">${member.name}</option>`);
        });
    });
}

const updateUserSettings = (El) => {
    let data = {};
    let name = $(El).attr("name");
    data[name] = $(El).is(':checked');

    $.ajax({
        method: "POST",
        url: '/c/profile/setting',
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        data: data
    }).done(function (response) {
        if (response.success) {
            $('#settingsAlert').removeClass('d-none');
            setTimeout(function () {
                $('#settingsAlert').addClass('d-none');
            }, 5000);
        }
    });
}

const formatPhone = () => {
    let phone = $("input[type='tel']");
    if (phone.length != 0) {
        phone.intlTelInput({
            preferredCountries: ["ng", "us"],
            nationalMode: false,
            utilsScript: "/js/custom/utils.js" // for formatting/placeholders etc
        });

        let phoneNumber = phone.val();
        if (phoneNumber.length != 0 && phoneNumber.charAt(0) == '+') {
            phone.val(phoneNumber.substr(1));
        }

        phone.on("keyup change", () => {
            let intlNumber = $(this).intlTelInput("getNumber");
            if (intlNumber) {
                $(this).val(intlNumber);
            } else {
                alert("Please enter a phone number.");
            }
        });
    }
};

$(() => {
    formatPhone();

    if ($('.searchLga').length != 0) {
        if ($('.searchLga').val().length != 0) {
            getLGAbyId('.searchLga');
        } else if ($('.searchState').val().length != 0) {
            getLGAsByStateId('.searchState', '.searchLga');
        }
    }

    if ($('.searchCommunity').length != 0) {
        if ($('.searchCommunity').val().length != 0) {
            getCommunityById('.searchCommunity');
        } else if ($('.searchLga').val().length != 0) {
            getCommunityByLGAId('.searchLga', '.searchCommunity');
        }
    }

    $('.teamSelect').select2({
        theme: "bootstrap4",
        width: '100%',
        allowClear: true,
        ajax: {
            url: '/c/team/all',
            dataType: 'json',
            delay: 500,
            data(params) {
                return {
                    ...params,
                    citizen() {
                        if ($('.teamSelect').data('citizen') == '1') {
                            return 1 ;
                        }
                        return 0;
                    }
                }
            }
        },
        placeholder: {
            id: '',
            text: ''
        },
    });

    $('input[type="file"]').change(function (e) {
        var fileName = e.target.files[0].name;
        $(e.target).next().html(fileName);
    });

    if ($('.lightbox').length > 0) $('.lightbox').magnificPopup({
        type: 'image'
    });

});


$("#export-btn").click(function(){
    $("#close-modal").click()
})