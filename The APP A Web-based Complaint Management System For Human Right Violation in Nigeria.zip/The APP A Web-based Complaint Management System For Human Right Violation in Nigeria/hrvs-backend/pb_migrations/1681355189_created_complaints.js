migrate((db) => {
  const collection = new Collection({
    "id": "17i7sh450hclv8g",
    "created": "2023-04-13 03:06:29.292Z",
    "updated": "2023-04-13 03:06:29.292Z",
    "name": "complaints",
    "type": "base",
    "system": false,
    "schema": [
      {
        "system": false,
        "id": "6vem1ysc",
        "name": "complainant_name",
        "type": "text",
        "required": true,
        "unique": false,
        "options": {
          "min": null,
          "max": null,
          "pattern": ""
        }
      },
      {
        "system": false,
        "id": "0fahoeum",
        "name": "complainant_email",
        "type": "email",
        "required": true,
        "unique": false,
        "options": {
          "exceptDomains": [],
          "onlyDomains": []
        }
      },
      {
        "system": false,
        "id": "ivrom9ei",
        "name": "complainant_gender",
        "type": "text",
        "required": true,
        "unique": false,
        "options": {
          "min": null,
          "max": null,
          "pattern": ""
        }
      },
      {
        "system": false,
        "id": "khimljkp",
        "name": "complainant_mobile",
        "type": "text",
        "required": true,
        "unique": false,
        "options": {
          "min": 6,
          "max": null,
          "pattern": ""
        }
      },
      {
        "system": false,
        "id": "xzqylio4",
        "name": "complainant_state",
        "type": "text",
        "required": false,
        "unique": false,
        "options": {
          "min": null,
          "max": null,
          "pattern": ""
        }
      },
      {
        "system": false,
        "id": "rb4rmhgy",
        "name": "victims",
        "type": "json",
        "required": true,
        "unique": false,
        "options": {}
      },
      {
        "system": false,
        "id": "ezcstkul",
        "name": "violators",
        "type": "json",
        "required": true,
        "unique": false,
        "options": {}
      },
      {
        "system": false,
        "id": "t4bfvwob",
        "name": "tickek_body",
        "type": "editor",
        "required": false,
        "unique": false,
        "options": {}
      }
    ],
    "indexes": [
      "CREATE INDEX `idx_uRUluOw` ON `complaints` (`complainant_email`)",
      "CREATE INDEX `idx_2ZcIE72` ON `complaints` (`complainant_name`)"
    ],
    "listRule": null,
    "viewRule": null,
    "createRule": null,
    "updateRule": null,
    "deleteRule": null,
    "options": {}
  });

  return Dao(db).saveCollection(collection);
}, (db) => {
  const dao = new Dao(db);
  const collection = dao.findCollectionByNameOrId("17i7sh450hclv8g");

  return dao.deleteCollection(collection);
})
