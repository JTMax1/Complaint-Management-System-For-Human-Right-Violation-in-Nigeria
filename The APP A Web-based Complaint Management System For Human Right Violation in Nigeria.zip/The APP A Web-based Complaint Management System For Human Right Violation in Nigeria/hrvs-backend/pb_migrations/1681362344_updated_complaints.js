migrate((db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("17i7sh450hclv8g")

  collection.listRule = "@request.auth.id = @collection.users.id || @request.auth.id = @request.data.complainant_email.id"

  return dao.saveCollection(collection)
}, (db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("17i7sh450hclv8g")

  collection.listRule = null

  return dao.saveCollection(collection)
})
