migrate((db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("17i7sh450hclv8g")

  // remove
  collection.schema.removeField("0fahoeum")

  // add
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "lhxamwof",
    "name": "complainant_email",
    "type": "relation",
    "required": true,
    "unique": false,
    "options": {
      "collectionId": "_pb_users_auth_",
      "cascadeDelete": false,
      "minSelect": null,
      "maxSelect": 1,
      "displayFields": [
        "username",
        "dob",
        "address",
        "mobile"
      ]
    }
  }))

  return dao.saveCollection(collection)
}, (db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("17i7sh450hclv8g")

  // add
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "0fahoeum",
    "name": "complainant_email",
    "type": "email",
    "required": true,
    "unique": false,
    "options": {
      "exceptDomains": [],
      "onlyDomains": []
    }
  }))

  // remove
  collection.schema.removeField("lhxamwof")

  return dao.saveCollection(collection)
})
