migrate((db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("17i7sh450hclv8g")

  // add
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "kfyrdxtz",
    "name": "complaint_status",
    "type": "select",
    "required": true,
    "unique": false,
    "options": {
      "maxSelect": 1,
      "values": [
        "progress",
        "resolved",
        "inadmissible",
        "ratified",
        "pending"
      ]
    }
  }))

  return dao.saveCollection(collection)
}, (db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("17i7sh450hclv8g")

  // remove
  collection.schema.removeField("kfyrdxtz")

  return dao.saveCollection(collection)
})
