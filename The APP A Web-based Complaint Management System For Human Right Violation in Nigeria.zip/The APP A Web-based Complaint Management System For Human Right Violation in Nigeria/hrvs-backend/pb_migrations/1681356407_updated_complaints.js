migrate((db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("17i7sh450hclv8g")

  // add
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "izpxde1u",
    "name": "complaint_info",
    "type": "json",
    "required": true,
    "unique": false,
    "options": {}
  }))

  return dao.saveCollection(collection)
}, (db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("17i7sh450hclv8g")

  // remove
  collection.schema.removeField("izpxde1u")

  return dao.saveCollection(collection)
})
